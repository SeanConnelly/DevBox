export class ContextMenu {

    constructor(ev,items) {
        console.dir(ev.target)
    }

}