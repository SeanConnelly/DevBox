import {App} from './js/app.js';

let app = new App();

